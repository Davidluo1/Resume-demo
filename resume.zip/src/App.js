export default function App() {
  return (
    <div class="resume">
      <div class="container">
        <div class="main">
          <nav class="intro-box">
            <h1 class="name">David Luo</h1>
            <p>Ethic: Asian</p>
            <p>phone: 3476364101</p>
          </nav>
          <section class="education">
            <h2>Education:</h2>
            <h4>New Utrecht HS, Brooklyn</h4>
            <p>
              High School diploma with overall average 86.11 (graduated in June
              2017)
            </p>
            <h4>Hunter College, Manhattan</h4>
            <p>Major: Computer Science</p>
            <p>Expected graduation date: 12/2021</p>
          </section>
          <section class="projects">
            <h2>Projects:</h2>
            <h4>User-Login-Game</h4>
            <span>Link: </span>
            <a
              href="https://github.com/Davidluo1/Project-User-login-.git"
              target="_blank"
              rel="noopener noreferrer"
            >
              Start login
            </a>
            <h4>Food App</h4>
            <span>Link: </span>
            <a
              href="https://github.com/Davidluo1/Food-App.git"
              target="_blank"
              rel="noopener noreferrer"
            >
              App
            </a>
            <br />
            <br />
            <span>Check out more: </span>
            <a
              href="https://qq422166745.wixsite.com/myportfolio"
              target="_blank"
              rel="noopener noreferrer"
            >
              Portfolio
            </a>
          </section>
          <section class="experience">
            <h2>Experience:</h2>
            <h4>CITY PARKS FOUNDATION, Flushing— Tennis instructor</h4>
            <p>
              Tennis instructor at CITY PARKS FOUNDATION in summer program 2019
              (teach around 50 children around age 6 – 18) organizing their
              training tasks. It improved my communication and management skills
            </p>
          </section>
        </div>
        <div class="sub-main">
          <nav class="info-box">
            <p>Email:</p>
            <p>qq422166745@icloud.com</p>
            <br />
            <p>Address:</p>
            <p>6228 136th ST New York, NY 11367</p>
          </nav>
          <section class="skill">
            <h2>Skill:</h2>
            <p>C++(more than 2 years)</p>
            <p>Python(1 year)</p>
            <h4>Self-taught:</h4>
            <p>Web design (HTML & CSS) Java script (less than 1 year)</p>
            <p>React (less than 1 year)</p>
          </section>
          <section class="awards">
            <h2>Awards:</h2>
            <p>
              New Utrecht High School PSAL Boy’s Tennis B Team 2013 – 2014
              Champions (second best player in the team)
            </p>
            <p>
              College of Staten Island Athletics 2017-2018 Men’s Tennis Rookie
              of the year on May 9
            </p>
            <p>
              CUNY Scholar-Athlete for the spring 2018 semester 3.216 GPA /
              Men’s Tennis
            </p>
            <p>
              Baruch College Men’s Tennis team championships 2019 Division III
              NCAA -2019 CUNYAC Men’s Tennis Champion award
            </p>
          </section>
          <section class="language">
            <h2>Language:</h2>
            <p>English</p>
            <p>Chinese(Mandarin)</p>
          </section>
        </div>
      </div>
    </div>
  );
}
